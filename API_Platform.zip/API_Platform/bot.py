from aiogram import executor, Bot,types,Dispatcher

bot = Bot()
dp = Dispatcher()
