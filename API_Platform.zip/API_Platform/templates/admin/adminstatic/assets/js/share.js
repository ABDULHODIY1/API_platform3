var share = document.querySelector("#share");

share.addEventListener("click",()=>{
    print(document)
})