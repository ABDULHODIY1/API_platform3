from rest_framework import viewsets, status, generics
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import login, logout, authenticate
from django.conf import settings
import stripe
import uuid

from .models import (
    User, UserProfile, ExternalAuth, Goal, UserGoal, Workout,
    WorkoutLesson, Notification, Insight, UserNotification, Post,
    Food, Exercise, MealPlan, UserProgress, HealthTips,
    PasswordResetRequest, UserActivityLog, Payment, SomeModel
)
from .serializers import (
    UserSerializer, UserProfileSerializer, ExternalAuthSerializer,
    GoalSerializer, UserGoalSerializer, WorkoutSerializer,
    WorkoutLessonSerializer, NotificationSerializer, InsightSerializer,
    UserNotificationSerializer, PostSerializer, FoodSerializer,
    ExerciseSerializer, MealPlanSerializer, UserProgressSerializer,
    HealthTipsSerializer, UserRegistrationSerializer,
    UserLoginSerializer, ChangePasswordSerializer,
    PasswordResetRequestSerializer, PasswordResetSerializer,
    UserActivityLogSerializer, PaymentSerializer, SomeModelSerializer
)
from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import login
from .serializers import UserLoginSerializer
stripe.api_key = settings.STRIPE_SECRET_KEY


# Payment handling using Stripe
class PaymentCreateViewSet(viewsets.ViewSet):
    def create(self, request):
        user_profile = UserProfile.objects.get(user=request.user)
        amount = request.data.get('amount')
        try:
            amount_in_cents = int(float(amount) * 100)
        except ValueError:
            return Response({'error': 'Invalid amount'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            charge = stripe.Charge.create(
                amount=amount_in_cents,
                currency='usd',
                customer=user_profile.stripe_customer_id,
                description=f'Charge for {user_profile.user.email}'
            )

            payment = Payment.objects.create(
                user_profile=user_profile,
                stripe_charge_id=charge.id,
                amount=amount,
                success=True
            )
            return Response(PaymentSerializer(payment).data, status=status.HTTP_201_CREATED)
        except stripe.error.StripeError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


# Food related views with custom actions
class FoodViewSet(viewsets.ModelViewSet):
    queryset = Food.objects.all()
    serializer_class = FoodSerializer

    @action(detail=False, methods=['get'])
    def high_protein(self, request):
        high_protein_foods = self.queryset.filter(protein__gte=20)
        serializer = self.get_serializer(high_protein_foods, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def low_carb(self, request):
        low_carb_foods = self.queryset.filter(carbs__lte=10)
        serializer = self.get_serializer(low_carb_foods, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def vegetarian(self, request):
        vegetarian_foods = self.queryset.filter(is_vegetarian=True)
        serializer = self.get_serializer(vegetarian_foods, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['post'])
    def total_calories(self, request):
        food_ids = request.data.get('food_ids', [])
        selected_foods = self.queryset.filter(id__in=food_ids)
        total_calories = sum(food.calories for food in selected_foods)
        return Response({'total_calories': total_calories})


# Other model viewsets with standard CRUD operations
class UserActivityLogViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = UserActivityLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return UserActivityLog.objects.filter(user=self.request.user)


class PasswordResetRequestViewSet(viewsets.ModelViewSet):
    queryset = PasswordResetRequest.objects.all()
    serializer_class = PasswordResetRequestSerializer


class SomeModelViewSet(viewsets.ModelViewSet):
    queryset = SomeModel.objects.all()
    serializer_class = SomeModelSerializer


class ExerciseViewSet(viewsets.ModelViewSet):
    queryset = Exercise.objects.all()
    serializer_class = ExerciseSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        min_calories = self.request.query_params.get('min_calories')
        if min_calories:
            queryset = queryset.filter(calories_burned__gte=min_calories)
        return queryset


# User-related views
class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer


class UserRegistrationView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserRegistrationSerializer





class UserLoginViewSet(viewsets.ViewSet):
    def create(self, request):
        serializer = UserLoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            login(request, user)

            # JWT tokenlarni yaratamiz
            refresh = RefreshToken.for_user(user)
            access_token = str(refresh.access_token)

            # Tokenlarni qaytarish
            return Response({
                "access": access_token,
                "refresh": str(refresh)
            }, status=status.HTTP_200_OK)

        # Agar login muvaffaqiyatsiz bo'lsa, xatolikni qaytarish
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserLogoutViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    def create(self, request):
        request.user.auth_token.delete()
        logout(request)
        return Response(status=status.HTTP_204_NO_CONTENT)


# Change password view
class ChangePasswordViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    def create(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if serializer.is_valid():
            user = request.user
            if not user.check_password(serializer.data.get("old_password")):
                return Response({"old_password": "Wrong password."}, status=status.HTTP_400_BAD_REQUEST)
            user.set_password(serializer.data.get("new_password"))
            user.save()
            return Response({"message": "Password changed successfully."}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Password reset handling
class PasswordResetViewSet(viewsets.ViewSet):
    def create(self, request):
        serializer = PasswordResetSerializer(data=request.data)
        if serializer.is_valid():
            reset_request = PasswordResetRequest.objects.filter(
                token=serializer.data.get("token"), is_used=False
            ).first()
            if reset_request:
                user = reset_request.user
                user.set_password(serializer.data.get("new_password"))
                user.save()
                reset_request.is_used = True
                reset_request.save()
                return Response({"message": "Password reset successfully."}, status=status.HTTP_200_OK)
            return Response({"error": "Invalid or used token."}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# Define other model viewsets as needed
# Goal and UserGoal related viewsets
class GoalViewSet(viewsets.ModelViewSet):
    queryset = Goal.objects.all()
    serializer_class = GoalSerializer


class UserGoalViewSet(viewsets.ModelViewSet):
    queryset = UserGoal.objects.all()
    serializer_class = UserGoalSerializer


# Workout and WorkoutLesson related viewsets
class WorkoutViewSet(viewsets.ModelViewSet):
    queryset = Workout.objects.all()
    serializer_class = WorkoutSerializer


class WorkoutLessonViewSet(viewsets.ModelViewSet):
    queryset = WorkoutLesson.objects.all()
    serializer_class = WorkoutLessonSerializer


# Notification and UserNotification viewsets
class NotificationViewSet(viewsets.ModelViewSet):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer


class UserNotificationViewSet(viewsets.ModelViewSet):
    queryset = UserNotification.objects.all()
    serializer_class = UserNotificationSerializer


# Insight-related viewsets
class InsightViewSet(viewsets.ModelViewSet):
    queryset = Insight.objects.all()
    serializer_class = InsightSerializer


# Post viewset
class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer


# MealPlan and UserProgress viewsets
class MealPlanViewSet(viewsets.ModelViewSet):
    queryset = MealPlan.objects.all()
    serializer_class = MealPlanSerializer


class UserProgressViewSet(viewsets.ModelViewSet):
    queryset = UserProgress.objects.all()
    serializer_class = UserProgressSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        user = self.request.user
        date_from = self.request.query_params.get('date_from')
        date_to = self.request.query_params.get('date_to')
        if date_from and date_to:
            queryset = queryset.filter(user=user, date__range=[date_from, date_to])
        return queryset


# HealthTips viewset
class HealthTipsViewSet(viewsets.ModelViewSet):
    queryset = HealthTips.objects.all()
    serializer_class = HealthTipsSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        category = self.request.query_params.get('category')
        if category:
            queryset = queryset.filter(category=category)
        return queryset


# External Authentication viewset
class ExternalAuthViewSet(viewsets.ModelViewSet):
    queryset = ExternalAuth.objects.all()
    serializer_class = ExternalAuthSerializer


# UserProfile viewset
class UserProfileViewSet(viewsets.ModelViewSet):
    queryset = UserProfile.objects.all()
    serializer_class = UserProfileSerializer

    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return UserProfile.objects.filter(user=user)
        return UserProfile.objects.none()
